package beris01.Lab6StateSurvey;

public class CancelledSurveyException extends Exception {
	public CancelledSurveyException() {
		super("\nYour survey was cancelled.");
	}
	public CancelledSurveyException(int age) {
		super("\nYou are too young to complete the survey.\nYour survey was cancelled.");
	}

}
