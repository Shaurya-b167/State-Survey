package beris01.Lab6StateSurvey;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;

public class StateSurvey {
	public static int getAge() throws CancelledSurveyException {
		Scanner reader= new Scanner(System.in);
		int age= 0;
		do {
            try {
                System.out.print("Please enter your age: ");
                String input_age = reader.nextLine().trim();
                if(input_age.equalsIgnoreCase("quit")) {
                	throw new CancelledSurveyException();
                }
                age= Integer.parseInt(input_age);
                if (age < 18) {
                    throw new CancelledSurveyException(age);
                }

            } catch (NumberFormatException e) {
                System.out.println("You've entered an invalid age.");
                age= 0;
                continue; // Continue the loop to ask for age again.
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
                break;
            } 
        } while (age <= 0);
		return age;
	} 
	
	public static String[][] readStateFile() {
		String stateData[][]= new String[50][2];
		String filePath = "states.bin";
		int stateCount = 0, maxStates= 50;
		try (DataInputStream dataInputStream = new DataInputStream(new FileInputStream(filePath))) {
            while (stateCount < maxStates) {
                String stateInfo = dataInputStream.readUTF();
                stateData[stateCount][0] = stateInfo;
                stateInfo = dataInputStream.readUTF();
                stateData[stateCount++][1] = stateInfo;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
		return stateData;
	}
	
	public static String getZIPCode() throws CancelledSurveyException {
		Scanner reader= new Scanner(System.in);
		String input_zip_code="";
		int zip_code= 0;
		do {
            try {
                System.out.print("Please enter your zip code: ");
                input_zip_code = reader.nextLine().trim();
                if(input_zip_code.equalsIgnoreCase("quit")) {
                	throw new CancelledSurveyException();
                }
                zip_code= Integer.parseInt(input_zip_code);
                if (input_zip_code.length()!=5) {
                    throw new IllegalArgumentException("Invalid zip code.");
                }

            } catch (NumberFormatException e) {
                System.out.println("Invalid input.");
                zip_code= 0;
                continue; // Continue the loop to ask for age again.
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
                zip_code= 0;
                continue;
            } 
        } while (zip_code <= 0);
		return input_zip_code;
	}
	
	public static String getState(String states[][]) throws CancelledSurveyException {
		Scanner reader= new Scanner(System.in);
		String abbreviation="";
		int i;
		do {
            try {
                System.out.print("Please enter the 2-letter state abbreviation: ");
                abbreviation = reader.nextLine().trim();
                if(abbreviation.equalsIgnoreCase("quit")) {
                	throw new CancelledSurveyException();
                }
                for(i=0; i<50; i++)
                if (states[i][0].equalsIgnoreCase(abbreviation)) {
                	return states[i][1];
                }
                if(i>=50)
                	throw new IllegalArgumentException("The state abbreviation was not found.");
            }
            catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
                abbreviation="";
                continue;
            } 
        } while (abbreviation=="");
		return "";
	}
	public static void main(String[] args) {
		try {
		System.out.println("Welcome to our survey. You may "
		+ "enter \"quit\" at any time to cancel the survey.");
		int age = getAge();
		String[][] states = readStateFile();
		String state = getState(states);
		String ZIPCode = getZIPCode();
		System.out.printf("\nAge:\t\t%d\n", age);
		System.out.printf("Address:\t%s %s\n\n", ZIPCode, state);
		System.out.println("Your survey is complete!");
		}
		catch (CancelledSurveyException e) {
		System.out.println(e.getMessage());
		}
		finally {
		System.out.println("Thank you for your time.");
		}
	}
}
